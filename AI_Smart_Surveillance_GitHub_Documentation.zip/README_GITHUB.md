# AI-Powered Smart Surveillance System

An intelligent computer-vision project for real-time person detection, mobile-phone detection, restricted-zone occupancy monitoring, and incident analytics. The project combines Python, OpenCV, YOLOv8, SQLite, and a Flask-based web dashboard.

## Project Overview

The system is designed to monitor a camera feed, detect people and mobile phones, evaluate activity inside a configurable region of interest (ROI), and record relevant incidents. A separate camera utility connects to a Hikvision-compatible RTSP stream and performs live face detection and people counting.

The repository contains two related computer-vision workflows:

1. **Smart Zone Occupancy & Phone Detection** — the main application, including detection, alerts, snapshots, CSV/SQLite incident logging, and a web analytics dashboard.
2. **Hikvision Live Face Detection & People Counter** — a separate RTSP camera utility that detects faces, draws bounding boxes, and displays a live count.

These workflows are separate entry points and should be configured and launched independently.

## Key Features

### Main surveillance application (`main.py`)
- Real-time camera processing using OpenCV.
- YOLOv8-based person and mobile-phone object detection.
- Configurable occupancy limit and rectangular region of interest.
- Phone/person association checks and consecutive-frame/time confirmation to reduce false alerts.
- Configurable detection confidence thresholds and alert/photo cooldowns.
- Automatic incident snapshot capture.
- CSV incident logging for easy inspection and export.
- SQLite persistence for dashboard queries.
- Optional desktop notification and sound integrations where supported.
- Guarded platform-specific notification code and graceful handling of blank email settings.

### Analytics dashboard (`dashboard.py`, `dashboard.html`)
- Flask web application.
- Summary statistics, including total incidents, recent activity, average confidence, and high-confidence counts.
- Interactive charts for incident timelines, confidence distribution, peak hours, and daily summaries.
- Incident search/filtering by time range and confidence threshold.
- Paginated incident table and snapshot links.
- System-health information and automatic refresh.
- Responsive browser interface using Bootstrap and Chart.js.

### Hikvision camera utility (`cam.py`)
- Connects to a camera through an RTSP stream.
- Uses the OpenCV DNN face detector with the supplied Caffe model files.
- Displays face bounding boxes and a live face count.
- Includes reconnect handling and runtime sensitivity adjustment.
- Intended as a separate utility, not as the dashboard's main YOLOv8 detection process.

## Technology Stack

| Area | Technology |
|---|---|
| Language | Python |
| Object detection | Ultralytics YOLOv8 |
| Image/video processing | OpenCV |
| Face detection utility | OpenCV DNN / Res10 SSD Caffe model |
| Web backend | Flask |
| Database | SQLite |
| Incident export/log | CSV |
| Frontend | HTML5, CSS3, JavaScript, Bootstrap |
| Data visualization | Chart.js |
| Camera input | Local webcam and RTSP camera streams |

## Repository Structure

```text
AI-Powered-Smart-Surveillance-System/
│
├── main.py                         # Main YOLOv8 zone/phone detection application
├── dashboard.py                    # Flask dashboard and JSON API
├── dashboard.html                  # Dashboard user interface
├── cam.py                          # Separate Hikvision RTSP face counter
│
├── validate_setup.py               # Checks required files and dependencies
├── test_server.py                  # Small snapshot-serving test server
├── setup_dirs.py                   # Creates the templates directory
├── START.bat                       # Windows launcher
├── START.ps1                       # PowerShell launcher
│
├── requirements.txt                # Main application dependencies
├── yolov8n.pt                      # YOLOv8 model weights (if distributed separately)
├── deploy.prototxt                 # OpenCV DNN face model configuration
├── res10_300x300_ssd_iter_140000.caffemodel
│                                  # OpenCV DNN face model weights
│
├── incident_log.csv                # Runtime incident log (generated/updated)
├── detection_incidents.db          # Runtime SQLite database (generated)
├── phone_incidents/                # Runtime snapshots (generated)
│
└── README.md
```

Documentation and delivery notes may also be retained in the repository, but this README is the consolidated entry point.

## Requirements

- Python 3.8 or later (use a compatible Python version for the installed package versions).
- Windows is the primary environment for the supplied `.bat` and notification launcher integrations. Core Python components may work on other operating systems, subject to camera drivers and optional notification support.
- A webcam for the main local-camera workflow, or a configured RTSP camera for the Hikvision utility.
- Working camera permissions and access to the required model files.
- Internet access may be required to install Python packages or download model assets.

## Installation

### 1. Clone the repository

```bash
git clone https://github.com/<YOUR-USERNAME>/AI-Powered-Smart-Surveillance-System.git
cd AI-Powered-Smart-Surveillance-System
```

Replace `<YOUR-USERNAME>` with your GitHub username.

### 2. Create and activate a virtual environment

```bash
python -m venv .venv
```

Windows Command Prompt:

```bat
.venv\Scripts\activate
```

PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

The supplied `requirements.txt` pins Flask, Ultralytics, OpenCV, and Winotify versions. The `cam.py` utility imports NumPy; install it if it is not already present:

```bash
pip install numpy
```

If package installation fails, check Python/package compatibility and consult the relevant package documentation before changing pinned versions.

### 4. Validate the setup

```bash
python validate_setup.py
```

Resolve missing required files or packages reported by the validator before starting the application.

## Running the Main Detection Application

### 1. Start the detection process

```bash
python main.py
```

The application opens the configured camera, runs person/phone detection, evaluates the configured zone, and records incidents when its detection conditions are met.

### 2. Start the dashboard in a second terminal

Activate the same virtual environment, then run:

```bash
python dashboard.py
```

Open the dashboard in a browser:

```text
http://127.0.0.1:5000
```

Keep the detection process and dashboard process running in separate terminals. The dashboard reads the incident database and snapshot directory used by the main application.

### Windows launch scripts

The repository includes:

```bat
START.bat
```

and:

```powershell
powershell -ExecutionPolicy Bypass -File START.ps1
```

Review the scripts before running them and ensure the virtual environment and working directory are correct.

## Running the Hikvision RTSP Face Counter

`cam.py` is a separate program. Before running it:

1. Open `cam.py`.
2. Configure the camera's RTSP address using your own camera details.
3. Do not commit camera usernames, passwords, IP addresses, or stream URLs containing credentials.
4. Confirm that the Caffe model configuration and weights are available.
5. Install the dependencies required by this utility, including `opencv-python` and `numpy`.

Run:

```bash
python cam.py
```

Use the controls described in the script: press `Q` in the video window to quit and use the up/down arrow keys to adjust sensitivity.

**Important:** The RTSP utility currently contains camera connection configuration in source code. Replace any real credentials and private network details with environment-based configuration before publishing the source publicly.

## Configuration

### Main application

The following settings are defined near the top of `main.py`:

| Setting | Purpose |
|---|---|
| `MAX_CAPACITY` | Maximum allowed number of people in the monitored zone |
| `CAMERA_INDEX` | Local camera index |
| `ROI_X1`, `ROI_Y1` | Top-left coordinate of the monitoring region |
| `ROI_X2`, `ROI_Y2` | Bottom-right coordinate of the monitoring region |
| `PERSON_CONF` | Person detection confidence threshold |
| `PHONE_CONF` | Phone detection confidence threshold |
| `PHONE_CONFIRM_SECONDS` | Required phone visibility confirmation period |
| `ALERT_COOLDOWN` | Minimum interval between sound alerts |
| `PHOTO_COOLDOWN` | Minimum interval between snapshots/pop-up notifications |
| `SNAPSHOT_FOLDER` | Folder used for incident images |

Adjust the ROI coordinates to match the camera resolution and the physical area being monitored. Detection thresholds may need calibration for lighting, camera angle, distance, and scene conditions.

### Dashboard

The dashboard configuration is defined in `dashboard.py`. Current defaults include:

- SQLite database: `detection_incidents.db`
- Snapshot directory: `phone_incidents`
- HTTP port: `5000`

The dashboard is intended for local use by default. Do not expose it directly to an untrusted network without adding authentication, access controls, HTTPS, and appropriate deployment hardening.

### RTSP camera utility

The RTSP address, confidence threshold, display dimensions, reconnect delay, and model file names are configured near the top of `cam.py`. Keep private camera settings outside public source control.

## Dashboard API

The Flask dashboard provides the following routes in the supplied implementation:

| Endpoint | Purpose |
|---|---|
| `/` | Dashboard page |
| `/api/stats` | Overall incident statistics |
| `/api/incidents` | Paginated incidents with query filters |
| `/api/timeline` | Incident timeline data |
| `/api/confidence-distribution` | Confidence score distribution |
| `/api/peak-hours` | Incident counts by hour |
| `/api/daily-summary` | Daily incident summary |
| `/api/system-health` | Detection/dashboard health information |
| `/api/snapshot/<filename>` | Serves a saved incident snapshot |

The incident endpoint accepts query parameters for time range, minimum confidence, and page number. Refer to `dashboard.py` for the exact implementation and response fields.

## Data Storage

The main application maintains incident information in CSV and SQLite:

- `incident_log.csv` — human-readable, portable incident log.
- `detection_incidents.db` — structured incident data used by the dashboard.
- `phone_incidents/` — captured incident images.

The application is documented as maintaining CSV logging alongside SQLite storage. Treat these files as runtime data, not source code. Back them up securely if they contain records that must be retained.

The database is created/initialized by the application. Do not upload real incident records, identifiable camera images, or private operational data to a public repository.

## Validation and Troubleshooting

Run:

```bash
python validate_setup.py
```

Common issues:

| Problem | Checks |
|---|---|
| Camera does not open | Check camera index, permissions, camera use by other applications, and device connectivity |
| RTSP stream fails | Verify camera network reachability, RTSP path, credentials, and stream permissions |
| Model file missing | Confirm model file location and download/access requirements |
| Missing Python package | Activate the intended virtual environment and install `requirements.txt` |
| Dashboard does not load | Confirm `dashboard.py` is running and port 5000 is available |
| No incidents appear | Confirm `main.py` is running and writing to the same database path used by the dashboard |
| Snapshots do not open | Check that the snapshot directory and referenced image files exist |
| Poor detection quality | Recalibrate confidence thresholds, ROI, camera position, lighting, and model suitability |

## Performance Notes

Performance depends on camera resolution, hardware, model, lighting, and the number of objects in the scene. Any FPS, memory, or latency figures in earlier project notes should be treated as environment-specific observations, not guaranteed benchmarks. Benchmark on the target deployment machine before relying on performance estimates.

## Privacy, Safety, and Security

This project processes camera imagery and may store incident snapshots. Deploy it responsibly:

- Obtain required permissions and follow applicable privacy and surveillance laws.
- Inform people where monitoring is legally required.
- Restrict access to camera streams, snapshots, logs, and the dashboard.
- Never publish RTSP credentials, private IP details, passwords, API keys, or personal incident data.
- Keep the dashboard bound to localhost unless secure remote access has been deliberately configured.
- Add authentication and HTTPS before any wider deployment.
- Establish retention and deletion policies for stored images and incident records.
- Do not treat automated detections as definitive proof of misconduct; review incidents with appropriate human oversight.

## Current Scope and Limitations

- Detection accuracy depends on the model and camera conditions; false positives and false negatives are possible.
- The main YOLOv8 workflow and Hikvision face-counting utility are separate processes.
- The dashboard reports data recorded by the detection application; it does not itself perform object detection.
- The supplied project does not establish production-grade authentication or role-based access for the dashboard.
- The supplied files do not establish a formal accuracy evaluation dataset or independently verified benchmark.

## Future Improvements

Potential extensions include:

- Authentication and role-based dashboard access.
- Secure configuration through environment variables.
- Multi-camera and multi-zone management.
- Structured event export and scheduled reports.
- Alert delivery integrations with secure credential management.
- Automated tests for detection logic and API endpoints.
- Containerized deployment and monitoring.
- Model evaluation using a labelled validation dataset.

## Contributing

Contributions are welcome. A useful contribution should include:

1. A clear description of the issue or enhancement.
2. Reproducible steps or test data that do not expose private footage.
3. Relevant test results.
4. Updated documentation where behavior or configuration changes.

## License

No license is specified in the supplied project files. Add a license only after confirming that you have the rights to distribute the source code and all included model weights/assets. Until a license is added, others do not automatically receive permission to reuse, modify, or redistribute the project.

## Acknowledgements

- [Ultralytics](https://github.com/ultralytics/ultralytics) — YOLO object-detection framework.
- [OpenCV](https://github.com/opencv/opencv) — computer-vision and DNN tooling.
- [Flask](https://github.com/pallets/flask) — Python web framework.
- [Bootstrap](https://getbootstrap.com/) — responsive UI framework.
- [Chart.js](https://www.chartjs.org/) — browser-based charts.

---

**Repository:** AI-Powered-Smart-Surveillance-System  
**Primary language:** Python  
**Project category:** Computer Vision · Object Detection · Smart Surveillance · Real-Time Analytics
